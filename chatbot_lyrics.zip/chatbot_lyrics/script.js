

document.addEventListener("DOMContentLoaded", function () {
    const chatContainer = document.getElementById("chat-container");
    const userInput = document.getElementById("user-input");
    const sendBtn = document.getElementById("send-btn");

    function appendMessage(text, sender) {
        const messageDiv = document.createElement("div");
        messageDiv.classList.add("message", sender);
        messageDiv.innerText = text;
        chatContainer.appendChild(messageDiv);
    }

    function showLoading() {
        let loadingBubble = document.createElement("div");
        loadingBubble.className = "message bot loading";
        loadingBubble.innerHTML = "<span class='dots'>.</span><span class='dots'>.</span><span class='dots'>.</span>";
        loadingBubble.id = "loading-bubble";

        chatContainer.appendChild(loadingBubble);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    function hideLoading() {
        let loadingBubble = document.getElementById("loading-bubble");
        if (loadingBubble) {
            loadingBubble.remove();
        }
    }

    function sendMessage() {
        const userMessage = userInput.value.trim();
        if (userMessage === "") return;

        appendMessage(userMessage, "user");
        userInput.value = "";

        showLoading();

        fetch("http://127.0.0.1:5000/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: userMessage }),
        })
        .then(response => response.json())
        .then(data => {
            setTimeout(() => { 
                hideLoading();
                appendMessage(data.response, "bot");
            }, 1000);  
        })
        .catch(error => {
            hideLoading();
            appendMessage("Error fetching lyrics. Please try again.", "bot");
            console.error("Error:", error);
        });
    }

    sendBtn.addEventListener("click", sendMessage);

    userInput.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            sendMessage();
        }
    });
});
