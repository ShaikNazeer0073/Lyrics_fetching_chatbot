import requests
from flask import Flask, request, jsonify
from flask_cors import CORS
from bs4 import BeautifulSoup
import re

app = Flask(__name__)
CORS(app)

Genius_ACCESS_TOKEN = "95ECCDKKG3X_H53NuiCJFBGnyX23IuTB19bGzDydcIpzVVehrUKaFJXjkVzF_FtZ"
GENIUS_API_BASE_URL = "https://api.genius.com"

headers = {
    "Authorization": f"Bearer {Genius_ACCESS_TOKEN}"
}

greetings = [
    "hi", "hii", "hello", "hey", "howdy", "greetings", "salutations",
    "namaste", "hola", "bonjour", "konnichiwa", "annyeonghaseyo",
    "ciao", "salaam", "shalom", "nǐ hǎo", "privet", "aloha",
    "good morning", "good afternoon", "good evening", "what's up",
    "yo", "hiya", "ello mate", "hey there", "hi folks", "heyy",
    "heyyy", "heyyyy", "excuse me" "hello there", "hiii", "heyy hi",
    "heyy hi there", "heyy hi hi", "heyy hi hi hi", "heyy hi hi hi hi","holaa"
]

lyrics_request = [
    "i need lyrics", "give me lyrics", "fetch lyrics", "lyrics please",
    "i need song lyrics" "get me lyrics", "lyrics for", "show me lyrics",
    "can you find lyrics", "lyrics of", "help me with lyrics", "lyrics request",
    "lyrics for song", "lyrics for the song", "lyrics of the song","need lyrics", "lyrics"
]

def search_song_on_genius(query: str) -> dict | None:
    search_url = f"{GENIUS_API_BASE_URL}/search"
    params = {"q": query}
    response = requests.get(search_url, headers=headers, params=params)

    if response.status_code == 200:
        json_data = response.json()
        hits = json_data["response"]["hits"]
        query_lower = query.lower()

        for hit in hits:
            title = hit["result"]["title"].lower()
            artist = hit["result"]["primary_artist"]["name"].lower()
            full_text = f"{title} by {artist}"
            if query_lower in full_text:
                return hit["result"]

        if hits:
            return hits[0]["result"]
    return None


def scrape_lyrics_from_url(song_url: str):
    try:
        page = requests.get(song_url)
        soup = BeautifulSoup(page.text, "html.parser")

        lyrics_divs = soup.find_all("div", attrs={"data-lyrics-container": "true"})
        raw_lyrics = ""
        if lyrics_divs:
            raw_lyrics = "\n".join([div.get_text(separator="\n").strip() for div in lyrics_divs])
        else:
            fallback_divs = soup.find_all("div", class_=re.compile("^Lyrics__Container"))
            raw_lyrics = "\n".join([div.get_text(separator="\n").strip() for div in fallback_divs])

        clean_lyrics = []
        for line in raw_lyrics.splitlines():
            line_lower = line.lower().strip()
            if (
                line_lower == ""
                or "contributor" in line_lower
                or "translation" in line_lower
                or "read more" in line_lower
                or "lyrics" in line_lower and not line_lower.startswith("[") 
                or any(lang in line_lower for lang in ["português", "français", "deutsch", "العربية", "türkçe", "español", "ελληνικά", "italiano", "polski", "한국어", "српски"])
            ):
                continue
            clean_lyrics.append(line)

        return "\n".join(clean_lyrics).strip() or "Lyrics not found."

    except Exception as e:
        return f"Error scraping lyrics: {str(e)}"


def get_lyrics(song_request: str):
    """Handles the overall flow: parse, search, scrape."""
    try:
        if "by" not in song_request:
            return "Please provide the song name and artist like this: 'Song Name by Artist'."

        parts = song_request.split(" by ")
        if len(parts) != 2:
            return "Please provide the song name and artist like this: 'Song Name by Artist'."

        song_name = parts[0].strip()
        artist_name = parts[1].strip()

        full_query = f"{song_name} {artist_name}"
        song_data = search_song_on_genius(full_query)

        if song_data:
            song_url = song_data.get("url")
            if song_url:
                lyrics = scrape_lyrics_from_url(song_url)
                return lyrics
            else:
                return "Couldn't find the song URL."
        else:
            return "Sorry, I don't have certification for this song."

    except Exception as e:
        return f"Error occurred while getting lyrics: {str(e)}"

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get("message", "").lower()

    if user_message in greetings:
        return jsonify({"response": "Heyy Hi!!"})

    elif any(phrase in user_message for phrase in lyrics_request):
        return jsonify({
            "response": "Sure! I am here to fetch lyrics. Please provide the song name and artist like this: 'Song Name by Artist'."
        })

    elif "by" in user_message:
        song_lyrics = get_lyrics(user_message)
        return jsonify({"response": song_lyrics})

    else:
        return jsonify({
            "response": "I'm sorry, I am only programmed for fetching lyrics."
        })

if __name__ == '__main__':
    app.run(debug=True)
